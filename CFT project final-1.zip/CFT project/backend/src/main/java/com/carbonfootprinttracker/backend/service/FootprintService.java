package com.carbonfootprinttracker.backend.service;


import com.fasterxml.jackson.databind.ObjectMapper;


import com.carbonfootprinttracker.backend.dto.FootprintRequest;
import com.carbonfootprinttracker.backend.model.CarbonFootprint;
import com.carbonfootprinttracker.backend.repository.FootprintRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class FootprintService {

    private final FootprintRepository repository;
    private final ObjectMapper objectMapper = new ObjectMapper();


    public FootprintService(FootprintRepository repository) {
        this.repository = repository;
    }

    public CarbonFootprint saveFootprint(FootprintRequest request) {
        Map<String, Object> d = request.getDetails();

        CarbonFootprint footprint = new CarbonFootprint();
        footprint.setDateRecorded(LocalDate.now());
        footprint.setTotalCarbon(request.getTotalFootprint());

        if (d != null) {
            footprint.setElectricityKwh(toDouble(d.get("electricity")));
            footprint.setCarKm(toDouble(d.get("carKm")));
            footprint.setShortFlights(toInt(d.get("shortFlights")));
            footprint.setLongFlights(toInt(d.get("longFlights")));
            footprint.setDiet(String.valueOf(d.get("diet")));
            try {
                footprint.setBreakdown(objectMapper.writeValueAsString(d));
            } catch (Exception e) {
                footprint.setBreakdown("{}");
            }

        }

        return repository.save(footprint);
    }

    public List<CarbonFootprint> getAllFootprints() {
        return repository.findAll();
    }

    private Double toDouble(Object v) {
        try {
            return v == null ? 0.0 : Double.parseDouble(v.toString());
        } catch (Exception e) {
            return 0.0;
        }
    }

    private Integer toInt(Object v) {
        try {
            return v == null ? 0 : Integer.parseInt(v.toString());
        } catch (Exception e) {
            return 0;
        }
    }
}
