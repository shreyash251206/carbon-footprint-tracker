package com.carbonfootprinttracker.backend.dto;

import java.util.Map;

public class FootprintRequest {
    private Double totalFootprint;
    private Map<String, Object> details;

    public Double getTotalFootprint() { return totalFootprint; }
    public void setTotalFootprint(Double totalFootprint) { this.totalFootprint = totalFootprint; }

    public Map<String, Object> getDetails() { return details; }
    public void setDetails(Map<String, Object> details) { this.details = details; }

    @Override
    public String toString() {
        return "FootprintRequest{" +
                "totalFootprint=" + totalFootprint +
                ", details=" + details +
                '}';
    }
}
