package com.carbonfootprinttracker.backend.repository;

import com.carbonfootprinttracker.backend.model.CarbonFootprint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FootprintRepository extends JpaRepository<CarbonFootprint, Long> {}
