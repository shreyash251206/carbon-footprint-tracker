package com.carbonfootprinttracker.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "footprint")
public class CarbonFootprint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double electricityKwh;
    private Double carKm;
    private Integer shortFlights;
    private Integer longFlights;
    private String diet;
    private Double totalCarbon;
    private LocalDate dateRecorded;

    @Column(columnDefinition = "TEXT")
    private String breakdown;

    // --- Getters & Setters ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getElectricityKwh() { return electricityKwh; }
    public void setElectricityKwh(Double electricityKwh) { this.electricityKwh = electricityKwh; }

    public Double getCarKm() { return carKm; }
    public void setCarKm(Double carKm) { this.carKm = carKm; }

    public Integer getShortFlights() { return shortFlights; }
    public void setShortFlights(Integer shortFlights) { this.shortFlights = shortFlights; }

    public Integer getLongFlights() { return longFlights; }
    public void setLongFlights(Integer longFlights) { this.longFlights = longFlights; }

    public String getDiet() { return diet; }
    public void setDiet(String diet) { this.diet = diet; }

    public Double getTotalCarbon() { return totalCarbon; }
    public void setTotalCarbon(Double totalCarbon) { this.totalCarbon = totalCarbon; }

    public LocalDate getDateRecorded() { return dateRecorded; }
    public void setDateRecorded(LocalDate dateRecorded) { this.dateRecorded = dateRecorded; }

    public String getBreakdown() { return breakdown; }
    public void setBreakdown(String breakdown) { this.breakdown = breakdown; }
}
