package com.carbonfootprinttracker.backend.controller;

import com.carbonfootprinttracker.backend.dto.FootprintRequest;
import com.carbonfootprinttracker.backend.model.CarbonFootprint;
import com.carbonfootprinttracker.backend.service.FootprintService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/footprint")
@CrossOrigin(origins = "http://localhost:5173")  // allow React frontend
public class FootprintController {

    private final FootprintService service;

    public FootprintController(FootprintService service) {
        this.service = service;
    }

    @PostMapping
    public CarbonFootprint saveFootprint(@RequestBody FootprintRequest request) {
        System.out.println("Received footprint request: " + request);
        return service.saveFootprint(request);
    }

    @GetMapping("/history")
    public List<CarbonFootprint> getAllFootprints() {
        return service.getAllFootprints();
    }
}
