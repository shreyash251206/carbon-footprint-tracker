import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  RefreshCw,
  Zap,
  Car,
  Plane,
  Utensils,
  Cloud,
  Save,
  Check,
} from "lucide-react";

const API_BASE_URL = "http://localhost:8080/api/footprint";

// Emission factors
const EMISSION_FACTORS = {
  ELECTRICITY_KWH: 0.233,
  CAR_KM: 0.192,
  SHORT_FLIGHT_KG: 100,
  LONG_FLIGHT_KG: 400,
  DIET_MEAT: 400,
  DIET_VEGETARIAN: 200,
  DIET_VEGAN: 100,
};

// --- Helper for calculation ---
const calculateFootprint = (inputs) => {
  const { electricityKWh, carKm, shortFlights, longFlights, diet } = inputs;
  const elec = (electricityKWh || 0) * EMISSION_FACTORS.ELECTRICITY_KWH;
  const car = (carKm || 0) * EMISSION_FACTORS.CAR_KM;
  const flights =
    (((shortFlights || 0) * EMISSION_FACTORS.SHORT_FLIGHT_KG +
      (longFlights || 0) * EMISSION_FACTORS.LONG_FLIGHT_KG) /
      12);
  let dietVal = EMISSION_FACTORS.DIET_MEAT;
  if (diet === "vegetarian") dietVal = EMISSION_FACTORS.DIET_VEGETARIAN;
  if (diet === "vegan") dietVal = EMISSION_FACTORS.DIET_VEGAN;

  const total = elec + car + flights + dietVal;

  const details = { electricity: elec, car: car, flights, diet: dietVal };

  return { totalFootprint: Math.round(total * 100) / 100, details };
};

// --- Reusable UI components ---
const InputField = ({ label, icon: Icon, unit, value, onChange, type = "number" }) => (
  <div className="flex flex-col space-y-1">
    <label className="text-sm font-medium text-gray-700 flex items-center">
      <Icon className="w-4 h-4 mr-2 text-indigo-500" />
      {label}
    </label>
    <div className="relative">
      <input
        type={type}
        value={value === 0 ? "" : value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
        className="w-full p-3 pr-16 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
        placeholder={`Enter ${label.toLowerCase()}...`}
        min="0"
      />
      <span className="absolute right-0 top-0 h-full flex items-center pr-3 text-sm text-gray-500">
        {unit}
      </span>
    </div>
  </div>
);

const DietSelector = ({ value, onChange }) => (
  <div className="flex flex-col space-y-1">
    <label className="text-sm font-medium text-gray-700 flex items-center">
      <Utensils className="w-4 h-4 mr-2 text-indigo-500" />
      Dietary Habits
    </label>
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
    >
      <option value="meat">Meat Eater</option>
      <option value="vegetarian">Vegetarian</option>
      <option value="vegan">Vegan</option>
    </select>
  </div>
);

const ResultCard = ({ title, value, unit, icon: Icon, color }) => (
  <div
    className={`p-4 bg-white rounded-xl shadow-lg border-t-4 border-${color}-500 flex items-center justify-between`}
  >
    <div>
      <p className="text-sm font-medium text-gray-500">{title}</p>
      <p className="text-2xl font-bold text-gray-900 mt-1">
        {value.toLocaleString()}{" "}
        <span className="text-base font-normal text-gray-500">{unit}</span>
      </p>
    </div>
    <div className={`p-3 rounded-full bg-${color}-100 text-${color}-600`}>
      <Icon className="w-6 h-6" />
    </div>
  </div>
);

// --- Main Calculator ---
const Calculator = () => {
  const [inputs, setInputs] = useState({
    electricityKWh: 0,
    carKm: 0,
    shortFlights: 0,
    longFlights: 0,
    diet: "meat",
  });

  const [history, setHistory] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const { totalFootprint, details } = useMemo(
    () => calculateFootprint(inputs),
    [inputs]
  );

  const fetchHistory = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/history`);
      if (!res.ok) throw new Error("Failed to fetch history");
      const data = await res.json();
      setHistory(data.reverse());
    } catch (err) {
      console.error("Error fetching history:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const payload = {
        totalFootprint,
        details: {
          electricity: inputs.electricityKWh,
          carKm: inputs.carKm,
          shortFlights: inputs.shortFlights,
          longFlights: inputs.longFlights,
          diet: inputs.diet,
        },
      };

      const res = await fetch(API_BASE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(`Save failed: ${res.status}`);
      await fetchHistory();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error("Error saving footprint:", err);
    } finally {
      setIsSaving(false);
    }
  };

  const previousFootprint = history.length > 0 ? history[0].totalCarbon : null;

  return (
    <div className="min-h-screen bg-gray-50 p-6 font-sans">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-extrabold text-indigo-800 flex items-center justify-center">
          <Cloud className="w-8 h-8 mr-3 text-indigo-500" />
          Carbon Footprint Calculator
        </h1>
        <p className="text-gray-600 mt-2">
          Calculate, track, and save your monthly CO₂ emissions.
        </p>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Inputs */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 border-b pb-3 flex items-center">
            <RefreshCw className="w-5 h-5 mr-2 text-green-500" />
            Monthly Calculator (kg CO₂e)
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InputField
              label="Electricity Usage"
              icon={Zap}
              unit="kWh"
              value={inputs.electricityKWh}
              onChange={(v) => setInputs({ ...inputs, electricityKWh: v })}
            />
            <InputField
              label="Car Distance Driven"
              icon={Car}
              unit="km"
              value={inputs.carKm}
              onChange={(v) => setInputs({ ...inputs, carKm: v })}
            />
            <InputField
              label="Short Flights (Annual)"
              icon={Plane}
              unit="flights"
              value={inputs.shortFlights}
              onChange={(v) => setInputs({ ...inputs, shortFlights: v })}
            />
            <InputField
              label="Long Flights (Annual)"
              icon={Plane}
              unit="flights"
              value={inputs.longFlights}
              onChange={(v) => setInputs({ ...inputs, longFlights: v })}
            />
            <div className="md:col-span-2">
              <DietSelector
                value={inputs.diet}
                onChange={(v) => setInputs({ ...inputs, diet: v })}
              />
            </div>
          </div>

          <div className="mt-8 pt-6 border-t">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">
              Breakdown
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div className="p-3 bg-indigo-50 rounded-lg">
                <p className="text-xs text-indigo-600">Electricity</p>
                <p className="font-bold">{details.electricity.toFixed(0)} kg</p>
              </div>
              <div className="p-3 bg-red-50 rounded-lg">
                <p className="text-xs text-red-600">Car</p>
                <p className="font-bold">{details.car.toFixed(0)} kg</p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-600">Flights</p>
                <p className="font-bold">{details.flights.toFixed(0)} kg</p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <p className="text-xs text-green-600">Diet</p>
                <p className="font-bold">{details.diet.toFixed(0)} kg</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="bg-indigo-600 p-6 rounded-2xl shadow-xl text-white text-center">
            <p className="text-lg opacity-80">Your Monthly Footprint</p>
            <p className="text-6xl font-extrabold mt-2">{totalFootprint}</p>
            <p className="text-2xl font-light opacity-90 mt-1">kg CO₂e</p>

            <button
              onClick={handleSave}
              disabled={isSaving}
              className={`mt-4 w-full flex items-center justify-center py-3 rounded-xl font-semibold text-indigo-800 transition
                ${
                  isSaving
                    ? "bg-indigo-300 cursor-not-allowed"
                    : "bg-white hover:bg-gray-100 shadow-md"
                }`}
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  Saving...
                </>
              ) : saveSuccess ? (
                <>
                  <Check className="w-5 h-5 mr-2 text-green-600" />
                  Saved!
                </>
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" />
                  Save Footprint
                </>
              )}
            </button>
          </div>

          <ResultCard
            title="Annual Projection"
            value={totalFootprint * 12}
            unit="kg CO₂e"
            icon={Cloud}
            color="blue"
          />
          {previousFootprint && (
            <ResultCard
              title="Last Recorded"
              value={previousFootprint}
              unit="kg CO₂e"
              icon={RefreshCw}
              color={
                totalFootprint > previousFootprint ? "red" : "green"
              }
            />
          )}
        </div>

        {/* History */}
        <div className="lg:col-span-3 bg-white p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 border-b pb-3">
            Tracking History
          </h2>

          {isLoading ? (
            <div className="flex justify-center items-center py-10 text-gray-500">
              <RefreshCw className="w-6 h-6 mr-2 animate-spin" />
              Loading history...
            </div>
          ) : history.length === 0 ? (
            <p className="text-gray-500 italic">
              No history yet. Save your first record!
            </p>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Total
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Electricity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Car
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Diet + Flights
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {history.map((h) => {
                  let breakdown = {};
                  try {
                    breakdown = JSON.parse(h.breakdown || "{}");
                  } catch {
                    breakdown = {};
                  }

                  // Safely convert to numbers
                  const electricity = Number(breakdown.electricity) || 0;
                  const car = Number(breakdown.car) || 0;
                  const diet = Number(breakdown.diet) || 0;
                  const flights = Number(breakdown.flights) || 0;

                  return (
                    <tr key={h.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        {new Date(h.dateRecorded).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        }) || "—"}
                      </td>
                      <td className="px-6 py-4 text-indigo-600 font-bold">
                        {Number(h.totalCarbon)?.toFixed(1)}
                      </td>
                      <td className="px-6 py-4">{electricity.toFixed(1)}</td>
                      <td className="px-6 py-4">{car.toFixed(1)}</td>
                      <td className="px-6 py-4">{(diet + flights).toFixed(1)}</td>
                    </tr>
                  );
                })}
              </tbody>

            </table>
          )}
        </div>
      </main>
    </div>
  );
};

export default Calculator;
