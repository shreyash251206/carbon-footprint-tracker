import React, { useEffect, useState } from "react";
import { Trophy, RefreshCw } from "lucide-react";

const Leaderboard = () => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    try {
      const res = await fetch("http://localhost:8080/api/footprint/history");
      const json = await res.json();
      setData(json);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="max-w-5xl mx-auto p-6 bg-white shadow-lg rounded-xl my-10">
      <h1 className="text-3xl font-bold text-gray-800 flex items-center mb-6">
        <Trophy className="w-7 h-7 text-yellow-500 mr-3" />
        Leaderboard & History
      </h1>

      {isLoading ? (
        <div className="flex justify-center py-12 text-gray-500">
          <RefreshCw className="w-6 h-6 mr-2 animate-spin" /> Loading data...
        </div>
      ) : data.length === 0 ? (
        <p className="text-gray-500 italic">No records found yet.</p>
      ) : (
        <table className="w-full border border-gray-200 rounded-lg text-sm">
          <thead className="bg-gray-100 text-gray-700 uppercase">
            <tr>
              <th className="py-3 px-4 text-left">Date</th>
              <th className="py-3 px-4 text-left">Total (kg CO₂e)</th>
              <th className="py-3 px-4 text-left">Electricity</th>
              <th className="py-3 px-4 text-left">Car</th>
              <th className="py-3 px-4 text-left">Flights + Diet</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50 border-t border-gray-100">
                <td className="py-3 px-4 text-gray-700">{item.dateRecorded}</td>
                <td className="py-3 px-4 font-semibold text-green-700">
                  {item.totalCarbon.toFixed(2)}
                </td>
                <td className="py-3 px-4">{item.electricityKwh ?? "-"}</td>
                <td className="py-3 px-4">{item.carKm ?? "-"}</td>
                <td className="py-3 px-4">
                  {(item.shortFlights ?? 0) + (item.longFlights ?? 0)} | {item.diet}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Leaderboard;
