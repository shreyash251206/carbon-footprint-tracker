import React from "react";
import { Cloud, ArrowRight, TrendingUp, Zap, Leaf, CheckCircle, Database, Award, BarChart2, Globe } from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  const primaryColor = "text-indigo-600";
  const buttonColor = "bg-indigo-600 hover:bg-indigo-700";

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center pt-20 pb-16">

      {/* --- Section 1: Hero & Core CTA --- */}
      <div className="max-w-7xl w-full px-6 md:px-8">
        <div className="bg-white shadow-2xl shadow-indigo-200/50 rounded-3xl p-10 sm:p-16 text-center border-t-8 border-indigo-500 relative overflow-hidden">

          {/* Main Icon - repositioned slightly for better visual flow with potential background */}
          <Cloud className={`w-28 h-28 ${primaryColor} mx-auto mb-8 opacity-90`} />

          {/* Main Heading */}
          <h1 className="text-7xl font-extrabold text-gray-900 mb-6 tracking-tight leading-tight">
            Pioneer Your Path to a <span className="text-indigo-600">Carbon-Neutral Future</span>
          </h1>

          {/* Subtitle with More Info */}
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-12 font-medium">
            Join a global community actively reducing their environmental impact. Our advanced platform provides **unparalleled accuracy, personalized insights, and powerful motivation** to help you understand and diminish your personal climate footprint.
          </p>

          {/* Call to Action (Key Element Kept) */}
          <Link
            to="/calculator"
            className={`${buttonColor} text-white px-12 py-5 rounded-full font-bold text-xl inline-flex items-center justify-center gap-3 transition duration-300 ease-in-out transform hover:scale-[1.03] shadow-lg shadow-indigo-400/50`}
          >
            Start Your Green Journey <ArrowRight className="w-6 h-6 ml-2" />
          </Link>
        </div>
      </div>

      {/* Image for the Hero Section */}
      <div className="max-w-7xl w-full px-6 md:px-8 mt-12">

      </div>

      {/* --- Section 2: Value Proposition (Way More Info - What You Get) --- */}
      <div className="max-w-7xl w-full mt-20 px-6 md:px-8">
        <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">
          Experience the Difference: Our Core Advantages
        </h2>

        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">

          {/* Value Card 1 */}
          <div className="p-7 bg-white rounded-xl shadow-md border-b-4 border-teal-500 hover:shadow-xl transition-all duration-300">
            <Zap className={`w-10 h-10 text-teal-500 mb-4`} />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Unmatched Data Precision</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              Leveraging the latest IPCC and national emission factor databases, we provide granular, reliable calculations for transportation, home energy, diet, and consumption, ensuring your results are always scientifically sound.
            </p>
          </div>

          {/* Value Card 2 */}
          <div className="p-7 bg-white rounded-xl shadow-md border-b-4 border-green-500 hover:shadow-xl transition-all duration-300">
            <TrendingUp className={`w-10 h-10 text-green-500 mb-4`} />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Dynamic Progress Visualization</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              Go beyond numbers with interactive charts and personalized dashboards. Visualize your footprint reduction over weeks, months, and years, set ambitious targets, and celebrate milestones on your journey to sustainability.
            </p>
          </div>

          {/* Value Card 3 */}
          <div className="p-7 bg-white rounded-xl shadow-md border-b-4 border-yellow-500 hover:shadow-xl transition-all duration-300">
            <Leaf className={`w-10 h-10 text-yellow-500 mb-4`} />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Hyper-Localized Actionable Tips</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              Receive practical, location-specific advice. From nearby sustainable transport options to local eco-friendly product suppliers and community initiatives, we connect you with tangible ways to reduce your impact.
            </p>
          </div>

          {/* Value Card 4 */}
          <div className="p-7 bg-white rounded-xl shadow-md border-b-4 border-red-500 hover:shadow-xl transition-all duration-300">
            <CheckCircle className={`w-10 h-10 text-red-500 mb-4`} />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Seamless & Intuitive Experience</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              Our award-winning interface is designed for simplicity. Effortlessly log activities, update consumption, and access your data in minutes each week, making carbon tracking an enjoyable, not daunting, task.
            </p>
          </div>
        </div>
      </div>

      {/* Image for Value Proposition Section */}
      <div className="max-w-7xl w-full px-6 md:px-8 mt-16">

      </div>

      {/* --- Section 3: Trust & Data Assurance (More Info on Security/Quality) --- */}
      <div className="max-w-7xl w-full mt-20 px-6 md:px-8">
        <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">
          Your Trust, Our Priority: Security & Scientific Rigor
        </h2>
        <div className="bg-indigo-50 p-10 rounded-2xl shadow-inner grid md:grid-cols-3 gap-10">

          {/* Trust Point 1 */}
          <div className="flex items-start gap-4">
            <Database className="w-9 h-9 flex-shrink-0 text-indigo-700 mt-1" />
            <div>
              <h3 className="text-2xl font-bold text-indigo-900">Ironclad Data Privacy</h3>
              <p className="text-gray-700 text-base leading-relaxed">
                Your personal emission data is paramount. We employ end-to-end encryption and adhere strictly to global data protection regulations (like GDPR) to ensure your information is always secure and confidential.
              </p>
            </div>
          </div>

          {/* Trust Point 2 */}
          <div className="flex items-start gap-4">
            <Award className="w-9 h-9 flex-shrink-0 text-indigo-700 mt-1" />
            <div>
              <h3 className="text-2xl font-bold text-indigo-900">Peer-Reviewed Methodology</h3>
              <p className="text-gray-700 text-base leading-relaxed">
                Our calculation models are built on publicly verifiable scientific standards and have been rigorously reviewed by leading environmental scientists and sustainability consultants to guarantee accuracy and credibility.
              </p>
            </div>
          </div>

          {/* Trust Point 3 */}
          <div className="flex items-start gap-4">
            <Link className="flex-shrink-0" to="/learn-more">
              <BarChart2 className="w-9 h-9 text-indigo-700 mt-1" />
            </Link>
            <div>
              <h3 className="text-2xl font-bold text-indigo-900">Transparent Reporting & Insights</h3>
              <p className="text-gray-700 text-base leading-relaxed">
                Gain access to comprehensive reports detailing your footprint breakdown and the impact of your changes. Our platform is designed to educate, allowing you to make truly informed decisions for the planet.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Image for Trust Section */}
      <div className="max-w-7xl w-full px-6 md:px-8 mt-16">

      </div>

      {/* --- New Section: Our Impact (Even More Info) --- */}
      <div className="max-w-7xl w-full mt-20 px-6 md:px-8 text-center">
        <h2 className="text-4xl font-bold text-gray-800 mb-12">
          Join a Movement: Our Collective Impact
        </h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-16">
          Every individual step collectively drives monumental change. See how our community is making a tangible difference worldwide.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="p-8 bg-white rounded-xl shadow-lg border-l-4 border-blue-500">
            <Globe className="w-12 h-12 text-blue-600 mb-4 mx-auto" />
            <div className="text-5xl font-extrabold text-gray-900 mb-2">150K+</div>
            <p className="text-lg text-gray-600">Active Users Globally</p>
          </div>
          <div className="p-8 bg-white rounded-xl shadow-lg border-l-4 border-pink-500">
            <TrendingUp className="w-12 h-12 text-pink-600 mb-4 mx-auto" />
            <div className="text-5xl font-extrabold text-gray-900 mb-2">2.5M+</div>
            <p className="text-lg text-gray-600">Tonnes CO2e Saved Annually</p>
          </div>
          <div className="p-8 bg-white rounded-xl shadow-lg border-l-4 border-purple-500">
            <Leaf className="w-12 h-12 text-purple-600 mb-4 mx-auto" />
            <div className="text-5xl font-extrabold text-gray-900 mb-2">90%</div>
            <p className="text-lg text-gray-600">Users Reduce Footprint</p>
          </div>
          <div className="p-8 bg-white rounded-xl shadow-lg border-l-4 border-orange-500">
            <CheckCircle className="w-12 h-12 text-orange-600 mb-4 mx-auto" />
            <div className="text-5xl font-extrabold text-gray-900 mb-2">#1</div>
            <p className="text-lg text-gray-600">Rated Carbon Tracking App</p>
          </div>
        </div>

        {/* Image for Impact Section */}
        <div className="mt-16">

        </div>
      </div>

    </div>
  );
};

export default Home;