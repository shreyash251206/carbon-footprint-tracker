import React from "react";
import { NavLink } from "react-router-dom";
import { Leaf, Calculator, BarChart3, Home } from "lucide-react";

const Navbar = () => {
  const navClass = ({ isActive }) =>
    `flex items-center gap-2 px-3 py-2 rounded-md transition ${
      isActive
        ? "bg-green-600 text-white"
        : "text-gray-700 hover:bg-green-100 hover:text-green-700"
    }`;

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50 border-b">
      <div className="max-w-6xl mx-auto flex justify-between items-center py-3 px-5">
        <div className="flex items-center gap-2 text-green-700 font-bold text-lg">
          <Leaf className="w-6 h-6" />
          Carbon Tracker
        </div>

        <div className="flex gap-4">
          <NavLink to="/" className={navClass}>
            <Home className="w-4 h-4" /> Home
          </NavLink>

          <NavLink to="/calculator" className={navClass}>
            <Calculator className="w-4 h-4" /> Calculator
          </NavLink>

          <NavLink to="/leaderboard" className={navClass}>
            <BarChart3 className="w-4 h-4" /> Leaderboard
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
