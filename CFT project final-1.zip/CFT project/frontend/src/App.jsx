import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Calculator from "./pages/Calculator";
import Leaderboard from "./pages/Leaderboard";

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Common Navbar */}
      <Navbar />

      {/* Page content */}
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/calculator" element={<Calculator />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
        </Routes>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 py-4 text-center text-gray-500 text-sm border-t">
        © {new Date().getFullYear()} Carbon Footprint Tracker
      </footer>
    </div>
  );
}

export default App;
